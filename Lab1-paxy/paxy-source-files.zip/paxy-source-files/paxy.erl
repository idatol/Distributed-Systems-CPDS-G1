-module(paxy).
-export([start/1, stop/0, stop/1]).

-define(RED, {255,0,0}). %Original
-define(BLUE, {0,0,255}). % Original
-define(GREEN, {0,255,0}). % Original
-define(YELLOW, {255,255,0}). %Added for p = 5
-define(PURPLE, {255,0,255}). %Added for p = 5
-define(CYAN, {0,255,255}). %Added for p = 7
-define(ORANGE, {255,128,0}). %Added for p = 7
-define(PINK, {255,105,180}). %Added for p = 9
-define(GREY, {128,128,128}). %Added for p = 9


% Sleep is a list with the initial sleep time for each proposer
start(Sleep) ->
  AcceptorNames = ["Homer", "Marge", "Bart", "Lisa", "Maggie"],
  %AcceptorNames = ["Homer", "Marge", "Bart", "Lisa", "Maggie", "Ida", "Lars"],
  %AcceptorNames = ["Homer", "Marge", "Bart", "Lisa", "Maggie", "Ida", "Lars", "Frank", "Maria"],
  %AcceptorNames = ["Homer", "Marge", "Bart", "Lisa", "Maggie", "Ida", "Lars", "Frank", "Maria", "Simen", "Greta"],


  AccRegister = [homer, marge, bart, lisa, maggie],
  %AccRegister = [homer, marge, bart, lisa, maggie, ida, lars],
  %AccRegister = [homer, marge, bart, lisa, maggie, ida, lars, frank, maria],
  %AccRegister = [homer, marge, bart, lisa, maggie, ida, lars, frank, maria, simen, greta],

  ProposerNames = [{"Fry", ?RED}, {"Bender", ?GREEN}, {"Leela", ?BLUE}, {"Herman", ?YELLOW}, {"Gary", ?PURPLE}, {"Ole", ?CYAN}, {"Dolle", ?ORANGE}, {"Doffen", ?PINK}, {"Barney", ?GREY}],
  PropInfo = [{fry, ?RED}, {bender, ?GREEN}, {leela, ?BLUE}, {herman, ?YELLOW}, {gary, ?PURPLE}, {ole, ?CYAN}, {dolle, ?ORANGE}, {doffen, ?PINK}, {barney, ?GREY}],

  register(gui, spawn(fun() -> gui:start(AcceptorNames, ProposerNames) end)),
  gui ! {reqState, self()},
  receive
    {reqState, State} ->
      {AccIds, PropIds} = State,
      start_acceptors(AccIds, AccRegister),
      spawn(fun() -> 
        Begin = erlang:monotonic_time(),
        start_proposers(PropIds, PropInfo, AccRegister, Sleep, self()),
        wait_proposers(length(PropIds)),
        End = erlang:monotonic_time(),
        Elapsed = erlang:convert_time_unit(End-Begin, native, millisecond),
        io:format("[Paxy] Total elapsed time: ~w ms~n", [Elapsed])
      end)
  end.
    
start_acceptors(AccIds, AccReg) ->
  case AccIds of
    [] ->
      ok;
    [AccId|Rest] ->
      [RegName|RegNameRest] = AccReg,
      register(RegName, acceptor:start(RegName, AccId)),
      start_acceptors(Rest, RegNameRest)
  end.

start_proposers(PropIds, PropInfo, Acceptors, Sleep, Main) ->
  case PropIds of
    [] ->
      ok;
    [PropId|Rest] ->
      [{RegName, Colour}|RestInfo] = PropInfo,
      [FirstSleep|RestSleep] = Sleep,
      proposer:start(RegName, Colour, Acceptors, FirstSleep, PropId, Main),	
      start_proposers(Rest, RestInfo, Acceptors, RestSleep, Main)
  end.

wait_proposers(0) ->
  ok;
wait_proposers(N) ->
  receive
    done ->
      wait_proposers(N-1)
  end.

stop() ->
  stop(homer),
  stop(marge),
  stop(bart),
  stop(lisa),
  stop(maggie),
  stop(gui).

stop(Name) ->
  case whereis(Name) of
    undefined ->
      ok;
    Pid ->
      Pid ! stop
  end.
